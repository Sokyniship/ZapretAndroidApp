package com.example.zapretapp

import android.net.VpnService
import android.os.ParcelFileDescriptor

class ZapretVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onCreate() {
        super.onCreate()
        val builder = Builder()
        builder.setSession("ZapretBypass")
            .addAddress("10.0.0.2", 32)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)
        vpnInterface = builder.establish()
    }

    override fun onDestroy() {
        super.onDestroy()
        vpnInterface?.close()
        vpnInterface = null
    }
}