package com.example.zapretapp

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(modifier = Modifier.fillMaxSize()) {
                VPNController()
            }
        }
    }
}

@Composable
fun VPNController() {
    var domainInput by remember { mutableStateOf("") }
    var domainList by remember { mutableStateOf(listOf<String>()) }
    var vpnRunning by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Сайты для обхода:", style = MaterialTheme.typography.titleLarge)
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(domainList.size) {
                Text(domainList[it])
            }
        }
        BasicTextField(
            value = domainInput,
            onValueChange = { domainInput = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        )
        Button(onClick = {
            if (domainInput.isNotBlank()) {
                domainList = domainList + domainInput.trim()
                domainInput = ""
            }
        }) {
            Text("Добавить сайт")
        }
        Button(onClick = {
            if (!vpnRunning) {
                val intent = VpnService.prepare(context)
                if (intent != null) {
                    (context as Activity).startActivityForResult(intent, 0)
                } else {
                    context.startService(Intent(context, ZapretVpnService::class.java))
                    vpnRunning = true
                }
            }
        }) {
            Text(if (vpnRunning) "VPN уже запущен" else "Запустить обход")
        }
    }
}